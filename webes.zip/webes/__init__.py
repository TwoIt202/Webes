"""
:authors: two-it2022
:license: Apache License, Version 1.0, see LICENSE file

:copyright: (0) 2022 two-it2022
"""

from .webes import (FilesEncoders)

__author__ = 'two-it2022'
__version__ = '0.0.1'
__email__ = 'kodland.group@gmail.com'